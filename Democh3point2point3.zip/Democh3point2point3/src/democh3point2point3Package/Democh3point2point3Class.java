package democh3point2point3Package;

public class Democh3point2point3Class {

	public static void main(String[] args) {
		boolean b = true;
		i = (int)b;
		
		int i = 1;
		boolean b = boolean i;

	}

}
